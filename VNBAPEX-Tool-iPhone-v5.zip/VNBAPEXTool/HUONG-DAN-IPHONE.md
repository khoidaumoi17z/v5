# VNBAPEX Tool v5 — nhiều kết quả và giao diện mới

## Những thay đổi trong bản này
- Đổi tên hiển thị, biểu tượng, tiêu đề và báo cáo thành **VNBAPEX Tool**. Giữ bundle ID để cài cập nhật bằng cùng cơ chế ký như bản trước.
- Giao diện tối màu xanh/cyan/tím, điều hướng nhanh, bốn ô thống kê. Bảng Phân tích được đặt ngay sau Nạp dữ liệu để dễ thấy toàn bộ kết quả.
- Giữ giới hạn **100 MiB mỗi tệp** và bộ đọc dump C theo từng phần.
- Mở rộng từ khóa: can thiệp mã, xác minh chữ ký; nhận tên camelCase. Bổ sung chuỗi **UTF-16LE chứa Basic Latin** bên cạnh ASCII.
- Đọc **BL trực tiếp ARM64** trong section mã. Chỉ giữ đích trùng mốc metadata. Vị trí lệnh gọi là địa chỉ giải mã; việc gán hàm chứa lệnh dựa trên khoảng metadata, chưa chứng minh ranh giới hàm thực tế.
- Kết hợp lời gọi theo tên trong dump C; mở rộng **một bước** đến hàm gọi hoặc được gọi bởi hàm có dấu hiệu. Các hàm liên quan không được tự gắn kết luận anticheat.
- Lọc theo loại kết quả, nguồn, nhóm dấu hiệu và địa chỉ; tìm nhiều từ khóa bằng dấu `|` (HOẶC).
- Đánh dấu nhiều dòng và xuất JSON chung. CSV/JSON toàn bộ vẫn gồm tất cả kết quả đang giữ, không chỉ 50 dòng của trang hiện tại.

## Vì sao ảnh trước chỉ hiện một offset?
Mục sinh mã chỉ tạo khung `.mm` cho **một hàm đang chọn**. Nó không biểu thị số kết quả tìm được trong binary. Bản v5 ghi tên hàm đang chọn rõ ràng và đưa thống kê tổng lên đầu màn hình.

Kiểm tra cùng tệp `anogs 10` đã cung cấp: **12.832 mục địa chỉ, 19 hàm/symbol có dấu hiệu, 8 hàm liên quan, 4 chuỗi có dấu hiệu**. Bộ quét tìm 44.723 lệnh BL, trong đó 37.798 lệnh có đích trùng mốc metadata. Đây là kết quả trên một tệp cụ thể, không phải đánh giá tỷ lệ tránh ban hoặc cam kết với mọi bản game.

## Cách xem nhiều kết quả
1. Nạp Mach-O. Chờ bảng thống kê cập nhật.
2. Mở **Khám phá dấu hiệu & quan hệ**. Đặt Loại = Hàm & chuỗi, Nguồn = Mọi nguồn, Nhóm = Mọi nhóm dấu hiệu.
3. Để tìm nhiều từ, nhập ví dụ `integrity | jailbreak | signature`. Dấu `|` có nghĩa “hoặc”, không phải biểu thức chính quy. Bấm Xóa bộ lọc để xem lại tất cả.
4. Chọn Nguồn = Qua quan hệ gọi hàm để đọc các hàm liên quan. Chọn một dòng để xem hàm gốc liên quan, hướng gọi, nguồn binary/C và vị trí lệnh BL nếu có.
5. Tích các ô ở đầu hàng, hoặc dùng Đánh dấu kết quả lọc (mỗi lần tối đa 5.000 dòng đầu). Chọn **Xuất mục đã chọn** để lấy JSON chung. Bộ sinh `.mm` vẫn dùng một hàm và ABI riêng đã xác minh.
6. Thứ tự “Ưu tiên đọc theo bằng chứng” dựa trên loại kết quả và số nhóm dấu hiệu khác nhau. Nó không phải xác suất là anticheat hay tỷ lệ “antiban”.

## C0 03 5F D6 là gì?
Trong ARM64 little-endian, đó là mã lệnh **RET X30**: quay về theo địa chỉ trả về. RET là lệnh phổ biến, không phải dấu hiệu nhận dạng anticheat. Nó không tự đặt giá trị trả về thành 0. Một bản sửa có đúng với ngữ cảnh hay không còn phụ thuộc luồng điều khiển, trạng thái stack/thanh ghi và cách bên gọi sử dụng kết quả. Việc thay bốn byte ở một địa chỉ bất kỳ không chứng minh tác dụng tránh phát hiện; có thể làm ứng dụng lỗi.

App không tự sửa byte hoặc tự chọn vị trí để thay RET. Kết quả phân tích giữ nguyên nguồn dữ liệu để đọc và đối chiếu.

Nguồn ARM: https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/RET--Return-from-subroutine-)
ABI ARM64: https://github.com/ARM-software/abi-aa/blob/main/aapcs64/aapcs64.rst

## Phạm vi của quan hệ và quét chuỗi
- Quan hệ binary chỉ từ BL trực tiếp đến mốc đã biết; chưa xử lý BLR, lời gọi qua con trỏ, tail-call, import stub hoặc XREF tới chuỗi.
- Không quét lệnh trong vùng được báo là mã hóa. Metadata vẫn có thể cho dấu hiệu từ tên symbol.
- Tối đa 100.000 quan hệ được giữ, 5.000 hàm liên quan và 16 quan hệ mẫu cho mỗi hàm liên quan; có chỉ báo khi đạt giới hạn danh sách. Không coi danh sách này là đầy đủ toàn bộ call graph.
- Tối đa 4.000 chuỗi trùng mẫu, dài 5–4.096 ký tự: ASCII hoặc UTF-16LE Basic Latin. UTF-16LE hỗ trợ vị trí bắt đầu chẵn/lẻ và ranh giới chunk; không phải bộ giải mã toàn bộ Unicode.
- Quan hệ từ dump C còn phụ thuộc giới hạn tên lời gọi của parser và tính đúng phiên bản. Không truyền kết luận bảo mật từ hàm này sang hàm khác.

---

## 1. Build và cập nhật app
1. Upload `VNBAPEX-Tool-iPhone-v5.zip` vào thư mục gốc repo GitHub `ipaoffset`. Giữ nguyên ZIP, không giải nén trước.
2. Lấy nội dung `VNBAPEX-build-ipa-v5.yml` kèm theo để thay file **`.github/workflows/build-ipa.yml`**. Đường dẫn workflow trong repo phải đúng như vậy, không có dấu chấm phía sau `.yml`.
3. Vào Actions → **Build VNBAPEX Tool v5** → Run workflow. Workflow giải nén, chạy test parser, tạo project bằng XcodeGen, build ARM64 và đóng gói IPA chưa ký.
4. Khi thành công, tải artifact `VNBAPEX-Tool-v5-unsigned-IPA`, giải nén để lấy IPA. Ký và cài theo phương thức bạn đã dùng cho v3.
5. Mở app và kiểm tra tiêu đề **v5.0**. Nếu còn v3.0, bạn đang dùng bản cũ. Source ZIP không phải IPA cài trực tiếp.

## 2. Chọn đúng tệp
- **Mở Mach-O iOS:** chọn binary thực thi/thư viện đã lấy ra từ IPA. Không cần đổi tên hoặc thêm phần mở rộng. Không chọn trực tiếp IPA, ZIP, APK hoặc `.so` ELF Android.
- **Mở dump C / SO.C:** chọn văn bản UTF-8 có định nghĩa hàm `sub_HEX` hoặc `FUN_HEX` và dấu ngoặc thân hàm. Khai báo, lời gọi riêng lẻ hoặc hàm đã đổi tên không có địa chỉ không đủ để tự lập bảng VA.
- **File `.asm` do app xuất không phải C.** Đọc nó bằng trình xem văn bản/công cụ phân tích; nhập lại qua nút dump C sẽ bị báo sai định dạng.
- Nếu không chọn được file qua nhà cung cấp Tệp như 3uTools, sao chép vào **Tệp → Trên iPhone → VNBAPEX Tool**, rồi chọn **Tệp trong ứng dụng → Mach-O/Dump C → tên file**. Đặt file trực tiếp trong thư mục, không đặt trong thư mục con.
- Dùng binary và dump C của cùng bản phát hành. Trùng địa chỉ không tự chứng minh cùng phiên bản. Nạp binary mới khi đã có binary trước đó sẽ bỏ dump C cũ để giảm nguy cơ trộn phiên bản.

## 3. Dump trên điện thoại
1. Nạp Mach-O; chờ thông báo thành công và danh sách section.
2. Trong **Dump mã ARM64 và dữ liệu**, chọn `__TEXT,__text` để đọc mã máy.
3. Thử **Bắt đầu trong section = `0x0`**, **Số byte = `0x100`** (256 byte), bấm **Dump ARM64 .asm** → Lưu vào Tệp.
4. Muốn xuất cả section, chọn lại section để lấy kích thước mặc định, giữ Bắt đầu = `0x0`.
5. Với `__cstring`, `__const`, `__data`, dùng HEX/BIN để xem dữ liệu. `__text` là mã, không tự đồng nghĩa anticheat; các section dữ liệu cũng không tự xác định vai trò bảo mật.
6. ASM/HEX giới hạn 64 MiB dữ liệu đầu vào mỗi lần xuất; BIN 100 MiB. Dung lượng văn bản xuất có thể lớn hơn nhiều so với byte đầu vào. Chia vùng nếu cần.

App đọc file tĩnh; không đọc bộ nhớ game khác, không giải mã FairPlay, không biến ASM thành mã giả C. Nếu cryptid khác 0, metadata vẫn có thể đọc nhưng ASM bị chặn vì vùng mã còn mã hóa.

## 4. Hiểu đúng địa chỉ
| Cột | Ý nghĩa |
|---|---|
| VA | Địa chỉ ảo trong Mach-O; với dump C đơn lẻ chỉ suy từ nhãn hàm |
| RVA (__TEXT) | VA trừ địa chỉ nền __TEXT |
| File offset | Vị trí byte tính từ đầu toàn bộ file; gồm phần dịch slice trong FAT binary |
| Slice offset | Vị trí tính từ đầu slice kiến trúc đã chọn |
| Địa chỉ chuỗi | Nơi chứa văn bản; không phải địa chỉ hàm dùng văn bản đó |

**Bắt đầu trong section** là độ lệch tính từ đầu section. Ví dụ minh họa: section bắt đầu VA `0x1000`, mục tiêu VA `0x1100` → nhập `0x100`. Đây là ví dụ số học, không phải offset của game. Chỉ áp dụng khi mục tiêu thuộc section đang chọn. Địa chỉ lúc chạy còn phụ thuộc ASLR.

## 5. Đọc bảng dấu hiệu anticheat
Bảng mục 5 được cập nhật sau khi nạp tệp; lọc theo **Hàm/symbol** hoặc **Chuỗi dữ liệu**. Chọn dòng để xem bằng chứng. Có thể xuất CSV/JSON toàn bộ dấu hiệu đang giữ, gồm địa chỉ và chú thích mức chắc chắn.

| Nhóm dấu hiệu | Ví dụ quy tắc | Cách diễn giải |
|---|---|---|
| Tên SDK/bảo mật | AnoSDK, AntiCheatExpert, anti-cheat, anti-tamper | Đầu mối về SDK/vai trò bảo mật; không chứng minh mọi hàm mang tên đó là kiểm tra gian lận |
| Tính toàn vẹn | integrity, checksum, tamper, code signature | Cần xác định dữ liệu được kiểm tra và cách dùng kết quả |
| Môi trường thiết bị | jailbreak, emulator detection | Có thể liên quan kiểm tra môi trường; cần đọc ngữ cảnh |
| Debugger | anti-debug, debugger attached | Chuỗi/tên chỉ là dấu hiệu, chưa đủ chứng minh hành vi |
| Báo cáo bảo mật | cheat report, security report | Chưa xác định nơi gửi, điều kiện gửi hay nội dung thực tế |
| API dùng chung | SHA, memcmp, sysctl, ptrace, liệt kê thư viện, đọc bộ nhớ | Bằng chứng yếu: nhiều chức năng bình thường cũng dùng các API này |

Không coi một giá trị `return -1`, `return 0`, tên `sub_...`, lời gọi mạng hoặc phép hash là bằng chứng đủ. Bộ quét bỏ comment khi xét dấu hiệu trong dump C, giữ nguyên nguồn chứng cứ và không gán chuỗi cho hàm gần nhất. Không có % “chắc chắn anticheat” hoặc danh sách “offset antiban” được tạo ra từ phỏng đoán.

## 6. Quy trình xác minh vai trò của một hàm
1. Ghi tên binary, bản phát hành, UUID và loại địa chỉ. Đối chiếu dump C với binary cùng bản.
2. Nếu dấu hiệu là chuỗi, tìm các tham chiếu đến chuỗi. App chưa phân tích XREF ARM64; chưa thể kết luận hàm nào sử dụng chuỗi chỉ từ bảng này.
3. Nếu dấu hiệu là hàm, đọc tham số, dữ liệu đầu vào, nhánh điều kiện, lời gọi và kết quả trả về. Bản xem trước có thể bị rút gọn, cần đối chiếu dump gốc.
4. Theo dõi nơi dùng kết quả: ghi log, xử lý lỗi, xác thực dữ liệu hay quyết định bảo mật? Giữ các giải thích thay thế, ví dụ kiểm tra checksum để xác minh tải file chứ không kiểm tra gian lận.
5. Chỉ mô tả vai trò có bằng chứng. Mẫu ghi chép: **giả thuyết → đoạn mã/chuỗi hỗ trợ → hàm gọi/được gọi → giải thích khác → điểm chưa xác minh**.
6. Không có kết quả không chứng minh không có anticheat: symbol có thể bị xóa, chuỗi mã hóa, hoặc logic nằm ở binary khác/phía máy chủ.

## 7. Làm tiếp trên Windows bằng Ghidra
1. Tải bản phát hành chính thức, cài Java theo hướng dẫn đi kèm đúng phiên bản và chạy `ghidraRun.bat`.
2. Tạo project local; import chính Mach-O đã phân tích; mở CodeBrowser và chạy phân tích tự động.
3. Đối chiếu địa chỉ nền/section. Dùng Go To với **VA** của mục tiêu. Không mặc định file offset là VA; nếu project đã rebase cần điều chỉnh theo địa chỉ nền mới.
4. Với chuỗi, xem References/XREF. Với hàm, xem Listing, Decompiler và các hàm gọi/được gọi.
5. Xác minh ý nghĩa theo quy trình mục 6. Mã decompiler là kết quả suy luận, không phải mã nguồn gốc; tên/kiểu có thể cần chỉnh sau phân tích.

Nguồn tham khảo chính thức:
- Ghidra và hướng dẫn cài: https://github.com/NationalSecurityAgency/ghidra
- Định dạng Mach-O: https://github.com/apple-oss-distributions/xnu/blob/main/EXTERNAL_HEADERS/mach-o/loader.h

## 8. Giới hạn kỹ thuật minh bạch
- Giới hạn nhập là 100 MiB mỗi tệp, không phải cam kết iOS luôn cấp đủ bộ nhớ. Mach-O vẫn cần một buffer đầu vào để đọc metadata; buffer được bỏ sau phân tích, model không giữ nó qua closure.
- Dump C đọc từng phần, không tạo chuỗi 100 MiB rồi nhân bản để mask comment. Giữ tối đa 100.000 hàm; vượt mức này báo lỗi và yêu cầu chia file.
- Bản xem trước: tối đa 32.768 ký tự/hàm, tổng 8.388.608 ký tự. Khi hết ngân sách, vẫn đọc tiếp và xét quy tắc dấu hiệu, nhưng không giữ toàn bộ thân hàm để hiển thị/xuất.
- Giữ tối đa 256 tên lời gọi/hàm và 24 bằng chứng đã khử trùng lặp/hàm. Chuỗi literal chỉ xét 4.096 ký tự đầu. Bộ đọc không phải trình biên dịch C/C++ đầy đủ.
- Quét binary xét chuỗi ASCII hoặc UTF-16LE Basic Latin in được, kết thúc NUL, dài 5–4.096 ký tự; giữ tối đa 4.000 chuỗi trùng quy tắc. Không quét đầy đủ Unicode UTF-16 hoặc giải mã chuỗi bị mã hóa. Nếu đạt giới hạn, giao diện ghi rõ.
- Metadata không bảo đảm liệt kê mọi hàm. Symbol có thể là nhãn. Giới hạn bảo vệ: 16.384 load command, 2.000.000 symbol và 100.000 mục hàm.
- CSV danh sách địa chỉ vẫn chứa các mục được parser giữ. JSON và phần đọc hàm chỉ có **bản xem trước** khi bị rút gọn, không thể dùng thay bản dump C gốc.
- Tên “image” đã đổi thành Tên file thực thi/thư viện lúc chạy, chỉ dùng khi sinh mã. Không cần điền để dump. ABI phải được xác minh; không điền số lượng tham số như `1` vào ô kiểu tham số.

## 9. Khi có lỗi
Dùng **Xuất nhật ký lỗi** và gửi cùng phiên bản app, dung lượng, loại file, thao tác gây lỗi. Lỗi 16 MiB nghĩa là vẫn đang chạy bản cũ. Nếu WebContent đóng, app báo chưa xác định nguyên nhân và yêu cầu nạp lại, không tự kết luận thiếu RAM. Phiên chưa được tự khôi phục.

## 10. Đã kiểm tra và chưa kiểm tra
Đã kiểm tra trên Linux/Node/JSDOM: nhập Mach-O 100 MiB, dump C 100 MiB theo từng phần, từ chối 100 MiB + 1 byte; các ranh giới chunk/UTF-8; phân trang, lọc, chọn dòng, trạng thái bận/reset; bằng chứng ngoài phần thân được giữ; bỏ comment; phân biệt ASM/C; địa chỉ chuỗi đối chiếu byte gốc; không đổi kết quả offset/CSV/khung mã của bộ kiểm tra cũ.

Tệp Mach-O thực tế đã đọc 12.832 mục địa chỉ. Tệp thử 100 MiB Mach-O là bản đệm thêm byte để kiểm tra dung lượng, không đại diện cho mọi binary phức tạp 100 MiB. Dump C thử 100 MiB chứa padding và hàm hợp lệ để kiểm tra đọc hết tệp, không đại diện cho mọi cấu trúc C/C++.

Chưa build bằng Xcode hoặc chạy UIKit/WebKit trên iPhone trong môi trường hiện tại. Workflow sẽ build thực tế trên macOS khi bạn chạy Actions. Chi tiết kiểm tra nằm trong `VALIDATION.json`; test parser và quan hệ trong thư mục `Tests`.

Bổ sung kiểm tra v5: Chromium ở kích thước điện thoại 390 px và desktop 1.240 px; nhập tệp thực, lọc quan hệ, tìm nhiều từ khóa và xuất nhiều mục đã qua. Ảnh xem trước được chụp từ giao diện chạy trong Chromium, không phải ảnh chạy trên iPhone thật.
