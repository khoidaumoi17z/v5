(function(){
'use strict';
const E=OffsetEvidence,el=id=>document.getElementById(id),checked=new Set();let findings=[],page=0,busy=false,graphStats={};
const id=f=>f.kind+':'+(f.va===null?'file'+f.fileOffset:f.va.toString())+':'+(f.encoding||'');
function addressNote(row){return row.sources.some(s=>s.includes('C dump'))?'VA có nhãn từ dump C; RVA/file offset ánh xạ theo binary đang nạp, chưa xác minh cùng phiên bản.':'Địa chỉ từ metadata; chưa xác minh vai trò chống gian lận.';}
function functionFinding(row,i,evidence,level='direct',relations=[]){return {kind:'function',name:row.name,va:row.va,rva:row.rva,fileOffset:row.fileOffset,sliceOffset:row.sliceOffset,section:model?.codeSection(row.va)?.name||'',certainty:level==='related'?'Liên quan qua lời gọi; chưa xác minh':E.certainty(evidence),addressNote:addressNote(row),evidence,rowIndex:i,dumpLine:row.dumpLine||null,level,relations};}
function refresh(){findings=[];checked.clear();const seeds=new Set();
 for(let i=0;i<rows.length;i++){const row=rows[i],evidence=E.forRow(row);if(!evidence.length)continue;seeds.add(row.va.toString());findings.push(functionFinding(row,i,evidence));}
 const connected=OffsetRelations.related(rows,model,seeds);graphStats=connected.stats;
 for(const item of connected.items){const evidence=item.relations.map(r=>({group:'relation',category:r.direction,kind:'relation',where:r.source,excerpt:`${OffsetDesk.hex(r.anchorVA)}${r.siteVA!==null?' · điểm gọi '+OffsetDesk.hex(r.siteVA):''}`}));findings.push(functionFinding(item.row,item.index,E.unique(evidence),'related',item.relations));}
 if(model?.stringFindings)findings.push(...model.stringFindings.map(f=>({...f,level:'direct'})));
 page=0;draw();
 const direct=findings.filter(f=>f.kind==='function'&&f.level==='direct').length,related=connected.items.length,strings=findings.filter(f=>f.kind==='string').length,scan=model?.stringScanStats;
 el('analysisSummary').textContent=`${direct} hàm/symbol có dấu hiệu · ${related} hàm liên quan một bước gọi · ${strings} chuỗi. Các kết quả cần được xác minh bằng ngữ cảnh mã.`+(scan?.truncated?` Chuỗi: giữ ${scan.limit||4000}/${scan.total} kết quả.`:'')+(graphStats.truncated||graphStats.relatedLimitReached?' Đã chạm giới hạn quan hệ; báo cáo không đầy đủ.':'');
 el('analysisDetail').textContent='Chọn một kết quả để xem bằng chứng, loại địa chỉ và quan hệ gọi hàm.';
 el('metricFunctions').textContent=rows.length.toLocaleString('vi-VN');el('metricIndicators').textContent=String(direct);el('metricRelated').textContent=String(related);el('metricStrings').textContent=String(strings);
 el('graphSummary').textContent=model?.encrypted?'Binary còn mã hóa: bỏ qua quét lời gọi ARM64.':`${model?.callGraph?.stats.resolvedBL||0} lệnh BL trỏ đúng mốc metadata · ${graphStats.edges||0} quan hệ được giữ (binary + C). Chưa xử lý BLR, lời gọi gián tiếp, tail-call hay XREF tới chuỗi.`;
}
function filtered(){const queries=el('analysisFilter').value.toLowerCase().split('|').map(s=>s.trim()).filter(Boolean),kind=el('analysisKind').value,group=el('analysisGroup').value,level=el('analysisLevel').value;
 return findings.filter(f=>(!kind||f.kind===kind)&&(!level||f.level===level)&&(!group||f.evidence.some(e=>e.group===group))&&(!queries.length||queries.some(q=>[f.name,OffsetDesk.hex(f.va),OffsetDesk.hex(f.rva),OffsetDesk.hex(f.fileOffset),...f.evidence.map(e=>e.category+' '+e.excerpt)].join(' ').toLowerCase().includes(q))))
 .sort((a,b)=>{if(el('analysisSort').value==='address'){if(a.va===null)return b.va===null?0:1;if(b.va===null)return -1;return a.va<b.va?-1:a.va>b.va?1:0;}const level=f=>f.kind==='string'?2:f.level==='related'?1:0;return level(a)-level(b)||new Set(b.evidence.map(e=>e.group)).size-new Set(a.evidence.map(e=>e.group)).size;});
}
function updateSelection(){el('analysisSelection').textContent=`Đã đánh dấu ${checked.size} kết quả`;el('analysisSelected').disabled=busy||!checked.size;}
function selectFinding(f){if(busy)return;
 el('analysisDetail').textContent=[f.kind==='function'?'HÀM / SYMBOL':'CHUỖI DỮ LIỆU',f.name,`VA ${OffsetDesk.hex(f.va)||'—'} · RVA ${OffsetDesk.hex(f.rva)||'—'} · file ${OffsetDesk.hex(f.fileOffset)||'—'}`,f.certainty,f.addressNote,...f.evidence.map(e=>`${e.category} | ${e.where}: ${e.excerpt}`),...(f.relations||[]).map(r=>`${r.direction}: ${OffsetDesk.hex(r.anchorVA)}; ${r.note}`)].join('\n');
 if(f.kind==='function')window.selectDeskRow(rows[f.rowIndex]);else {selected=null;clearOutput();el('generate').disabled=true;el('details').textContent='Đang chọn chuỗi dữ liệu; chưa xác định hàm tham chiếu.';el('source').value='';el('selectedSummary').textContent='Chuỗi dữ liệu • không phải một hàm';}
}
function draw(){const shown=filtered();page=Math.min(page,Math.max(0,Math.ceil(shown.length/50)-1));el('analysisRows').replaceChildren();
 for(const f of shown.slice(page*50,page*50+50)){
  const tr=document.createElement('tr'),checkCell=document.createElement('td'),check=document.createElement('input');check.type='checkbox';check.checked=checked.has(id(f));check.disabled=busy;check.setAttribute('aria-label','Đánh dấu '+f.name);check.onclick=e=>e.stopPropagation();check.onchange=()=>{check.checked?checked.add(id(f)):checked.delete(id(f));updateSelection();};checkCell.appendChild(check);tr.appendChild(checkCell);
  const nameCell=document.createElement('td'),title=document.createElement('span'),address=document.createElement('span');title.className='finding-title';title.textContent=f.name;title.title=f.name;address.className='finding-address';address.textContent=(f.kind==='string'?'Chuỗi':'Hàm')+' · VA '+(OffsetDesk.hex(f.va)||'chưa biết');nameCell.append(title,address);tr.appendChild(nameCell);
  for(const value of [f.kind==='string'?'Chuỗi '+(f.encoding||''):f.level==='related'?'Hàm liên quan':'Hàm / symbol',OffsetDesk.hex(f.rva)||'—',OffsetDesk.hex(f.fileOffset)||'—',f.certainty]){const td=document.createElement('td');td.textContent=value;td.title=value;tr.appendChild(td);}
  tr.tabIndex=0;tr.onclick=()=>selectFinding(f);tr.onkeydown=e=>{if(e.target===tr&&(e.key==='Enter'||e.key===' ')){e.preventDefault();selectFinding(f);}};el('analysisRows').appendChild(tr);
 }
 el('analysisPage').textContent=`${shown.length} kết quả · ${page+1}/${Math.max(1,Math.ceil(shown.length/50))}`;el('analysisPrev').disabled=page===0;el('analysisNext').disabled=(page+1)*50>=shown.length;el('analysisCSV').disabled=el('analysisJSON').disabled=busy||!findings.length;el('analysisMark').disabled=busy||!shown.length;el('analysisClear').disabled=busy||!checked.size;updateSelection();
}
function payload(list=findings){return {tool:'VNBAPEX Tool 5.0',sourceName,dumpName,uuid:model?.uuid||null,base:model?.base??null,notice:'Unverified indicators. Relations do not establish anti-cheat roles. String addresses are data locations. Caller boundaries in binary are metadata intervals. No estimated ban-prevention success rate.',rules:'evidence.js v2 + direct BL / C call relations',dumpStats:window.dumpImportStats||null,stringScanStats:model?.stringScanStats||null,graphStats,binaryCallStats:model?.callGraph?.stats||null,findings:list.map(({rowIndex,...f})=>f)};}
function exportJSON(list,name){download(name,JSON.stringify(payload(list),(k,v)=>typeof v==='bigint'?OffsetDesk.hex(v):v,2),'application/json');}
window.setAnalysisBusy=value=>{busy=!!value;draw();};
const previous=window.rebuild;window.rebuild=function(){previous();refresh();};
let timer;el('analysisFilter').oninput=()=>{clearTimeout(timer);timer=setTimeout(()=>{page=0;draw();},150);};for(const key of ['analysisKind','analysisLevel','analysisGroup','analysisSort'])el(key).onchange=()=>{page=0;draw();};el('analysisPrev').onclick=()=>{page--;draw();};el('analysisNext').onclick=()=>{page++;draw();};
el('analysisResetFilter').onclick=()=>{for(const key of ['analysisFilter','analysisKind','analysisLevel','analysisGroup'])el(key).value='';el('analysisSort').value='evidence';page=0;draw();};
el('analysisMark').onclick=()=>{for(const f of filtered().slice(0,5000))checked.add(id(f));draw();};el('analysisClear').onclick=()=>{checked.clear();draw();};el('analysisSelected').onclick=()=>exportJSON(findings.filter(f=>checked.has(id(f))),'VNBAPEX-selected-findings.json');
el('analysisJSON').onclick=()=>exportJSON(findings,'VNBAPEX-analysis.json');
el('analysisCSV').onclick=()=>{const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';const fields=['type','level','name','va','rva','file_offset','status','address_note','evidence'];const lines=findings.map(f=>[f.kind,f.level,f.name,OffsetDesk.hex(f.va),OffsetDesk.hex(f.rva),OffsetDesk.hex(f.fileOffset),f.certainty,f.addressNote,f.evidence.map(e=>e.category+': '+e.excerpt).join(' | ')].map(quote).join(','));download('VNBAPEX-findings.csv','\ufeff'+fields.join(',')+'\r\n'+lines.join('\r\n'),'text/csv;charset=utf-8');};
refresh();
})();
