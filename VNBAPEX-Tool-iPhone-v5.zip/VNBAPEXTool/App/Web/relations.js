/* Static references only. BL sites are decoded from bytes; caller boundaries are metadata intervals. */
(function(root){
'use strict';
const LIMIT=100000;
function binary(bytes,model){
 const edges=[],stats={scannedInstructions:0,directBL:0,resolvedBL:0,stored:0,truncated:false,skipped:model.encrypted?'Vùng mã còn mã hóa':''};
 if(model.encrypted)return {edges,stats};
 const targets=new Map(model.rows.map(r=>[r.va.toString(),r]));
 for(const section of model.sections){
  if(!(section.name==='__text'||(section.flags&0x80000400)!==0)||['__stubs','__auth_stubs','__stub_helper'].includes(section.name)||section.va%4n||!section.size)continue;
  const range=model.map(section.va),end=model.map(section.va+section.size-1n);
  if(!range||!end||end.fileOffset!==range.fileOffset+section.size-1n)continue;
  const offset=Number(range.fileOffset),size=Number(section.size);if(offset<0||offset+size>bytes.length)continue;
  const functions=model.rows.filter(r=>r.va>=section.va&&r.va<section.va+section.size).map(r=>({va:r.va,relative:Number(r.va-section.va)}));let cursor=-1;
  for(let p=0;p+4<=size;p+=4){
   stats.scannedInstructions++;while(cursor+1<functions.length&&functions[cursor+1].relative<=p)cursor++;
   const q=offset+p,w=(bytes[q]|bytes[q+1]<<8|bytes[q+2]<<16|bytes[q+3]<<24)>>>0;
   if(w>>>26!==0x25)continue;stats.directBL++;
   let imm=w&0x03ffffff;if(imm&0x02000000)imm-=0x04000000;
   const siteVA=section.va+BigInt(p),targetVA=siteVA+BigInt(imm*4);if(!targets.has(targetVA.toString()))continue;stats.resolvedBL++;
   if(edges.length>=LIMIT){stats.truncated=true;continue;}
   edges.push({callerVA:cursor>=0?functions[cursor].va:null,siteVA,targetVA,source:'ARM64 BL',note:'Điểm gọi giải mã trực tiếp; hàm chứa điểm gọi suy theo khoảng giữa các mốc metadata, chưa xác minh ranh giới.'});
  }
 }
 stats.stored=edges.length;return {edges,stats};
}
function combine(rows,model){
 const edges=[...(model?.callGraph?.edges||[])],names=new Map(),seen=new Set();let truncated=!!model?.callGraph?.stats.truncated;let byVA;
 for(const row of rows){for(const n of [row.name,'sub_'+row.va.toString(16).toUpperCase(),'FUN_'+row.va.toString(16)]){if(!names.has(n))names.set(n,row);else if(names.get(n)?.va!==row.va)names.set(n,null);}}
 for(const row of rows)for(const name of row.calls||[]){let target=names.get(name);
  if(!target){const m=/^(?:sub_|FUN_)([0-9a-f]+)$/i.exec(name);if(m)target=rowsByVA().get(BigInt('0x'+m[1]).toString());}
  if(!target)continue;const key=row.va+'>'+target.va;if(seen.has(key))continue;seen.add(key);
  if(edges.length>=LIMIT){truncated=true;continue;}
  edges.push({callerVA:row.va,targetVA:target.va,siteVA:null,source:'Dump C',note:'Quan hệ tên lời gọi trong dump C; địa chỉ nhãn và phiên bản chưa xác minh.'});
 }
 function rowsByVA(){return byVA||(byVA=new Map(rows.map(r=>[r.va.toString(),r])));}
 return {edges,truncated};
}
function related(rows,model,seeds){
 const graph=combine(rows,model),byVA=new Map(rows.map((r,i)=>[r.va.toString(),{row:r,index:i}])),found=new Map();
 function add(va,anchor,edge,direction){if(va===null||seeds.has(va.toString()))return;const item=byVA.get(va.toString());if(!item)return;
  const key=va.toString();if(!found.has(key)){if(found.size>=5000)return;found.set(key,{...item,relations:[]});}
  const list=found.get(key).relations;if(list.length<16)list.push({anchorVA:anchor,direction,siteVA:edge.siteVA,source:edge.source,note:edge.note});
 }
 for(const edge of graph.edges){if(seeds.has(edge.targetVA.toString()))add(edge.callerVA,edge.targetVA,edge,'Gọi hàm có dấu hiệu');if(edge.callerVA!==null&&seeds.has(edge.callerVA.toString()))add(edge.targetVA,edge.callerVA,edge,'Được hàm có dấu hiệu gọi');}
 return {items:[...found.values()],stats:{edges:graph.edges.length,truncated:graph.truncated,relatedLimitReached:found.size>=5000}};
}
const api={binary,combine,related};root.OffsetRelations=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
